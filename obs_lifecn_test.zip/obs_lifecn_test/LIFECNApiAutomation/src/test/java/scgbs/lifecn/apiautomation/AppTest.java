package scgbs.lifecn.apiautomation;

import org.testng.annotations.*;

public class AppTest {
	
	@BeforeSuite
	public void setUpSuite() {
		System.out.println("setUp Suite");
	}
	
	@BeforeTest
	public void setUpTest() {
		System.out.println("setUp Test");
	}
	
	@BeforeClass
	public void setUpClass() {
		System.out.println("setUp Class");
	}
	
	@Test(groups = { "fast" })
	public void aFastTest() {
		System.out.println("Fast test");
	}
	
	@Test(groups = { "slow" })
	public void aSlowTest() {
		System.out.println("Slow test");
	}
	
}
