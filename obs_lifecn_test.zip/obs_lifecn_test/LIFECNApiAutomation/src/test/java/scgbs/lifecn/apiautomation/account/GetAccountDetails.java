package scgbs.lifecn.apiautomation.account;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.testng.Assert;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.SoapUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;
import scgbs.lifecn.apiautomation.XMLUtil;


public class GetAccountDetails extends APIBaseTest {
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException, DocumentException {
		System.out.println("Run the test for account " + data.get("AccountNumber"));
		String strUserName = ConfigurationUtil.getPropertyByName("OBSUserName");
		String strPassword = ConfigurationUtil.getPropertyByName("OBSPassword");
		String strAddress = "https://10.20.175.66:5501/ws/scbCoreBankingAccount.v6.ws.providerV3:Account/scbCoreBankingAccount_v6_ws_providerV3_Account_Port";
		String strSoapRequest = generateSoapRequest(data);
		Map<String, Object> mapRequestResult = SoapUtil.getSoapResponse(strUserName, strPassword, strAddress, strSoapRequest);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException, DocumentException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		Assert.assertEquals(strStatusCode, "200", "Check response code");
		String strSoapResponse = mapRequestResult.get("SoapResponse").toString();
		Map<String, String> mapNameSpaces = new HashMap<String, String>();
		mapNameSpaces.put("ns", "http://www.sc.com/SCBML-1");
		mapNameSpaces.put("acc", "http://www.sc.com/coreBanking/v6/account");
		Node nodeOperatingInstruction = XMLUtil.findNodeByXPath(strSoapResponse, "//acc:operatingInstruction", mapNameSpaces);
		Node nodeCurrencyCode = XMLUtil.findNodeByXPath(strSoapResponse, "//acc:currencyCode", mapNameSpaces);
		Node nodeCode = XMLUtil.findNodeByXPath(strSoapResponse, "//acc:branch/acc:code", mapNameSpaces);
		Node nodeFlag = XMLUtil.findNodeByXPath(strSoapResponse, "//acc:flag", mapNameSpaces);
		ValidationUtil.assertEquals(nodeOperatingInstruction.getText(), data.get("OperatingInstruction"), "Check operatingInstruction");
		ValidationUtil.assertEquals(nodeCurrencyCode.getText(), data.get("CurrencyCode"), "Check currencyCode");
		ValidationUtil.assertEquals(nodeCode.getText(), data.get("Code"), "Check code");
		ValidationUtil.assertEquals(nodeFlag.getText(), data.get("Flag"), "Check flag");
	}
	
	private String generateSoapRequest(Map<String, String> data) {
		String strAccountNumber = String.valueOf(data.get("AccountNumber"));
		StringBuffer sbRequest = new StringBuffer();
		sbRequest.append("<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">");
		sbRequest.append("  <soap:Body>");
		sbRequest.append("    <ns4:getAccountDetails xmlns:ns2=\"http://www.sc.com/coreBanking/v6/account\" xmlns:ns3=\"http://www.sc.com/SCBML-1\" xmlns:ns4=\"http://www.sc.com/coreBanking/v6/ws/provider/Account\">");
		sbRequest.append("      <getAccountDetailsRequest>");
		sbRequest.append("        <ns3:header>");
		sbRequest.append("          <ns3:messageDetails>");
		sbRequest.append("            <ns3:messageVersion>6.0</ns3:messageVersion>");
		sbRequest.append("            <ns3:messageType>");
		sbRequest.append("              <ns3:typeName>CoreBanking:Account</ns3:typeName>");
		sbRequest.append("              <ns3:subType>");
		sbRequest.append("                <ns3:subTypeName>getAccountDetails</ns3:subTypeName>");
		sbRequest.append("              </ns3:subType>");
		sbRequest.append("            </ns3:messageType>");
		sbRequest.append("          </ns3:messageDetails>");
		sbRequest.append("          <ns3:originationDetails>");
		sbRequest.append("            <ns3:messageSender>");
		sbRequest.append("              <ns3:messageSender>OBS</ns3:messageSender>");
		sbRequest.append("              <ns3:senderDomain>");
		sbRequest.append("                <ns3:domainName>CoreBanking</ns3:domainName>");
		sbRequest.append("                <ns3:subDomainName>");
		sbRequest.append("                  <ns3:subDomainType>OBS</ns3:subDomainType>");
		sbRequest.append("                </ns3:subDomainName>");
		sbRequest.append("              </ns3:senderDomain>");
		sbRequest.append("              <ns3:countryCode>CN</ns3:countryCode>");
		sbRequest.append("            </ns3:messageSender>");
		sbRequest.append("            <ns3:messageTimestamp>2018-04-24T10:58:12.252</ns3:messageTimestamp>");
		sbRequest.append("            <ns3:initiatedTimestamp>2018-04-24T10:58:12.252</ns3:initiatedTimestamp>");
		sbRequest.append("            <ns3:trackingId>OBS-eb56c7af-2632-49a1-abcd-7dd2ccbcfc27</ns3:trackingId>");
		sbRequest.append("            <ns3:possibleDuplicate>false</ns3:possibleDuplicate>");
		sbRequest.append("          </ns3:originationDetails>");
		sbRequest.append("          <ns3:captureSystem>eBBS</ns3:captureSystem>");
		sbRequest.append("          <ns3:process>");
		sbRequest.append("            <ns3:processName>getAccountDetails</ns3:processName>");
		sbRequest.append("            <ns3:eventType>Select</ns3:eventType>");
		sbRequest.append("          </ns3:process>");
		sbRequest.append("        </ns3:header>");
		sbRequest.append("        <ns2:getAccountDetailsReqPayload>");
		sbRequest.append("          <ns3:payloadFormat>XML</ns3:payloadFormat>");
		sbRequest.append("          <ns3:payloadVersion>1.0</ns3:payloadVersion>");
		sbRequest.append("          <ns2:getAccountDetailsReq>");
		sbRequest.append("            <ns2:accountNumber>" + strAccountNumber + "</ns2:accountNumber>");
		sbRequest.append("            <ns2:accountCurrencyCode>CNY</ns2:accountCurrencyCode>");
		sbRequest.append("            <ns2:companyID xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"); 
		sbRequest.append("          </ns2:getAccountDetailsReq>");
		sbRequest.append("        </ns2:getAccountDetailsReqPayload>");
		sbRequest.append("      </getAccountDetailsRequest>");
		sbRequest.append("    </ns4:getAccountDetails>");
		sbRequest.append("  </soap:Body>");
		sbRequest.append("</soap:Envelope>");
		return sbRequest.toString();
	}
	
}
