package scgbs.lifecn.apiautomation.customer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.testng.Assert;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.SoapUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;
import scgbs.lifecn.apiautomation.XMLUtil;


public class GetCustomerContactDetails extends APIBaseTest {
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException, DocumentException {
		System.out.println("Run the test for user " + data.get("CustomerIdentificationNumber"));
		String strUserName = ConfigurationUtil.getPropertyByName("OBSUserName");
		String strPassword = ConfigurationUtil.getPropertyByName("OBSPassword");
		String strAddress = "https://10.20.175.66:5501/ws/scbCoreBankingCustomer.v5.ws.provider.v3:Customer/scbCoreBankingCustomer_v5_ws_provider_v3_Customer_Port";
		String strSoapRequest = generateSoapRequest(data);
		Map<String, Object> mapRequestResult = SoapUtil.getSoapResponse(strUserName, strPassword, strAddress, strSoapRequest);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException, DocumentException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		Assert.assertEquals(strStatusCode, "200", "Check response code");
		String strSoapResponse = mapRequestResult.get("SoapResponse").toString();
		Map<String, String> mapNameSpaces = new HashMap<String, String>();
		mapNameSpaces.put("ns", "http://www.sc.com/SCBML-1");
		mapNameSpaces.put("cust", "http://www.sc.com/coreBanking/v5/customer");
		Node nodeAddressLanguageCode = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:addressLanguageCode", mapNameSpaces);
		Node nodeAddressTypeCode = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:addressTypeCode", mapNameSpaces);
		Node nodePostBox = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:postBox", mapNameSpaces);
		Node nodeMailingAddressIndicator = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:mailingAddressIndicator", mapNameSpaces);
		Node nodePostalCode = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:postalCode", mapNameSpaces);
		Node nodeStateofResidence = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:stateofResidence", mapNameSpaces);
		Node nodeCountryCode = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:countryCode", mapNameSpaces);
		Node nodeContactDetailsEMail = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:contactDetails[cust:contactType = '" + data.get("ContactTypeEMail") + "']", mapNameSpaces);
		Node nodeContactTypeClassificationEMail = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:contactDetails[cust:contactType = '" + data.get("ContactTypeEMail") + "']/cust:contactTypeClassification", mapNameSpaces);
		Node nodeContactEMailAddress = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:contactEMailAddress", mapNameSpaces);
		Node nodeContactDetailsMobile = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:contactDetails[cust:contactType = '" + data.get("ContactTypeMobile") + "']", mapNameSpaces);
		Node nodeContactTypeClassificationMobile = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:contactDetails[cust:contactType = '" + data.get("ContactTypeMobile") + "']/cust:contactTypeClassification", mapNameSpaces);
		Node nodeContactTelephoneNumber = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:contactTelephoneNumber", mapNameSpaces);
		ValidationUtil.assertEquals(nodeAddressLanguageCode.getText(), data.get("AddressLanguageCode"), "Check addressLanguageCode");
		ValidationUtil.assertEquals(nodeAddressTypeCode.getText(), data.get("AddressTypeCode"), "Check addressTypeCode");
		ValidationUtil.assertEquals(nodePostBox.getText(), data.get("PostBox"), "Check postBox");
		ValidationUtil.assertEquals(nodeMailingAddressIndicator.getText(), data.get("MailingAddressIndicator"), "Check mailingAddressIndicator");
		ValidationUtil.assertEquals(nodePostalCode.getText(), data.get("PostalCode"), "Check postalCode");
		ValidationUtil.assertEquals(nodeStateofResidence.getText(), data.get("StateofResidence"), "Check stateofResidence");
		ValidationUtil.assertEquals(nodeCountryCode.getText(), data.get("CountryCode"), "Check countryCode");
		ValidationUtil.assertTrue(nodeContactDetailsEMail != null, "Check contactTypeEMail");
		ValidationUtil.assertEquals(nodeContactTypeClassificationEMail.getText(), data.get("ContactTypeClassificationEMail"), "Check contactTypeClassificationEMail");
		ValidationUtil.assertEquals(nodeContactEMailAddress.getText(), data.get("ContactEMailAddress"), "Check contactEMailAddress");
		ValidationUtil.assertTrue(nodeContactDetailsMobile != null, "Check contactTypeMobile");
		ValidationUtil.assertEquals(nodeContactTypeClassificationMobile.getText(), data.get("ContactTypeClassificationMobile"), "Check contactTypeClassificationMoBile");
		ValidationUtil.assertEquals(nodeContactTelephoneNumber.getText(), data.get("ContactTelephoneNumber"), "Check contactTelephoneNumber");
	}
	
	private String generateSoapRequest(Map<String, String> data) {
		String strCustomerIdentificationNumber = String.valueOf(data.get("CustomerIdentificationNumber"));
		StringBuffer sbRequest = new StringBuffer();
		sbRequest.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cus=\"http://www.sc.com/coreBanking/v5/ws/provider/customer\" xmlns:scb=\"http://www.sc.com/SCBML-1\" xmlns:cus1=\"http://www.sc.com/coreBanking/v5/customer\">");
		sbRequest.append("  <soapenv:Header/>");
		sbRequest.append("  <soapenv:Body>");
		sbRequest.append("    <cus:getCustomerContactDetails>");
		sbRequest.append("      <getCustomerContactDetailsRequest>");
		sbRequest.append("        <scb:header>");
		sbRequest.append("          <scb:messageDetails>");
		sbRequest.append("            <scb:messageVersion>5.0</scb:messageVersion>");
		sbRequest.append("            <scb:messageType>");
		sbRequest.append("              <scb:typeName>CoreBanking:customer</scb:typeName>");
		sbRequest.append("              <scb:subType>");
		sbRequest.append("                <scb:subTypeName>getCustomerContactDetails</scb:subTypeName>");
		sbRequest.append("              </scb:subType>");
		sbRequest.append("            </scb:messageType>");
		sbRequest.append("          </scb:messageDetails>");
		sbRequest.append("          <scb:originationDetails>");
		sbRequest.append("            <scb:messageSender>");
		sbRequest.append("              <scb:messageSender>OBS</scb:messageSender>");
		sbRequest.append("              <scb:senderDomain>");
		sbRequest.append("                <scb:domainName>CoreBanking</scb:domainName>");
		sbRequest.append("                <scb:subDomainName>");
		sbRequest.append("                  <scb:subDomainType>OBS</scb:subDomainType>");
		sbRequest.append("                </scb:subDomainName>");
		sbRequest.append("              </scb:senderDomain>");
		sbRequest.append("              <scb:countryCode>CN</scb:countryCode>");
		sbRequest.append("            </scb:messageSender>");
		sbRequest.append("            <scb:messageTimestamp>2016-04-22T11:36:45.716</scb:messageTimestamp>");
		sbRequest.append("            <scb:initiatedTimestamp>2016-04-22T11:36:45.717</scb:initiatedTimestamp>");
		sbRequest.append("            <scb:trackingId>b1197777-6789-6789-99bf-bb9c71</scb:trackingId>");
		sbRequest.append("            <scb:possibleDuplicate>true</scb:possibleDuplicate>");
		sbRequest.append("          </scb:originationDetails>");
		sbRequest.append("          <scb:captureSystem>eBBS</scb:captureSystem>");
		sbRequest.append("          <scb:process>");
		sbRequest.append("            <scb:processName>getCustomerContactDetails</scb:processName>");
		sbRequest.append("            <scb:eventType>Select</scb:eventType>");
		sbRequest.append("          </scb:process>");
		sbRequest.append("        </scb:header>");
		sbRequest.append("        <cus1:getCustomerContactDetailsReqPayload>");
		sbRequest.append("          <scb:payloadFormat>XML</scb:payloadFormat>");
		sbRequest.append("          <scb:payloadVersion>5.2</scb:payloadVersion>");
		sbRequest.append("          <cus1:getCustomerContactDetailsReq>");
		sbRequest.append("            <cus1:customerIdentificationNumber>" + strCustomerIdentificationNumber + "</cus1:customerIdentificationNumber>");
		sbRequest.append("          </cus1:getCustomerContactDetailsReq>");
		sbRequest.append("        </cus1:getCustomerContactDetailsReqPayload>");
		sbRequest.append("      </getCustomerContactDetailsRequest>");
		sbRequest.append("    </cus:getCustomerContactDetails>");
		sbRequest.append("  </soapenv:Body>");
		sbRequest.append("</soapenv:Envelope>");
		return sbRequest.toString();
	}
	
}
