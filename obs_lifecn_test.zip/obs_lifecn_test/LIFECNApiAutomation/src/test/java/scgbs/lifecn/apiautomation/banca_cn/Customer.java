package scgbs.lifecn.apiautomation.banca_cn;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.RestUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;

import org.json.JSONObject;


public class Customer extends APIBaseTest {
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException {
		System.out.println("====== Run the test case " + data.get("CaseInfo") + " with the user " + data.get("RelationshipId") + " ======");
		String strAddress = ConfigurationUtil.getPropertyByName("OBS-CN-Backend") + "/banca/cn/customers/" + data.get("RelationshipId");
		Map<String, String> mapHeaders = new HashMap<String, String>();
		mapHeaders.put("csl_user", "{\"relId\":\"" + data.get("RelationshipId") + "\"}");
		Map<String, Object> mapRequestResult = RestUtil.getRestResponseByGet(strAddress, mapHeaders);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		ValidationUtil.assertEquals(strStatusCode, "200", "Check response code");
		String strRestResponse = mapRequestResult.get("RestResponse").toString();
		
		JSONObject joResponse = new JSONObject(strRestResponse);
		JSONObject joData = joResponse.getJSONObject("data");
		JSONObject joAttributes = joData.getJSONObject("attributes");
		String strDateOfBirthActual = joAttributes.getString("dateOfBirth");
		ValidationUtil.assertEquals(strDateOfBirthActual, data.get("DateOfBirth"), "Check account name");
	}
	
}
