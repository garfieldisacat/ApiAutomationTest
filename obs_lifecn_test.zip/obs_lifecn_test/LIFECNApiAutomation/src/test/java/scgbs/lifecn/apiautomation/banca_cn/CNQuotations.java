package scgbs.lifecn.apiautomation.banca_cn;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.RestUtil;
import scgbs.lifecn.apiautomation.SQLServerUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;

import org.json.JSONArray;
import org.json.JSONObject;


public class CNQuotations extends APIBaseTest {
	
	@BeforeClass
	public void initializeDBTable() throws Exception {
		System.out.println("********* Start of initializing the DB Table obs_customer_policy *********");
		SQLServerUtil objSqlServerConn = null;
		try {
			objSqlServerConn = new SQLServerUtil(ConfigurationUtil.getPropertyByName("SQLServer-Connection-URL"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-UserName"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-Password"));
			objSqlServerConn.initializeBeforeExecuteSQL();
			Date dtToday = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String strToday = sdf.format(dtToday);
			objSqlServerConn.executeStatement("update obs_job_audit set last_success_date = '" + strToday + "' where job_name = 'CustomerPolicy:Job:'");
			objSqlServerConn.executeStatement("delete from obs_customer_policy");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027181', '300263976', 807835.50, 'Y', 'Y', '10', '" + strToday + "')");
		}
		catch (Exception e) {
			
		}
		finally {
			objSqlServerConn.closeAfterExecuteSQL();
			System.out.println("********* End of initializing the DB Table obs_customer_policy *********");
		}
	}
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException {
		System.out.println("====== Run the test case " + data.get("CaseInfo") + " with the user " + data.get("RelationshipId") + " ======");
		String strAddress = ConfigurationUtil.getPropertyByName("OBS-CN-Backend") + "/banca/cn/cnquotations";
		String strRestRequest = generateRestRequest(data);
		Map<String, String> mapHeaders = new HashMap<String, String>();
		mapHeaders.put("csl_user", "{\"relId\":\"" + data.get("RelationshipId") + "\"}");
		Map<String, Object> mapRequestResult = RestUtil.getRestResponseByPost(strAddress, strRestRequest, mapHeaders);
		checkPoints(data, mapRequestResult);
	}
	
	private String generateRestRequest(Map<String, String> data) {
		JSONObject joDetailJson = new JSONObject();
		joDetailJson.put("count", "1");
		joDetailJson.put("insuranceCode", "213");
		joDetailJson.put("policyFrequency", "05");
		joDetailJson.put("policyTerm", "100");
		
		joDetailJson.put("sumAssured", data.get("SumAssured"));
		joDetailJson.put("paymentFrequency", data.get("PaymentFrequency"));
		if ("01".equals(data.get("PaymentFrequency"))) {
			joDetailJson.put("paymentTerm", "0");
		}
		else {
			joDetailJson.put("paymentTerm", data.get("PaymentTerm"));
			joDetailJson.put("autoPayFlag", "1");
		}
		joDetailJson.put("payMethod", data.get("PaymentFrequency"));
		joDetailJson.put("cashDividendOption", "1");
		
		joDetailJson.put("annualIncome", data.get("AnnualIncome"));
		joDetailJson.put("familyAnnualIncome", data.get("FamilyAnnualIncome"));
		joDetailJson.put("incomeSource", "工资");
		joDetailJson.put("insuranceBudget", data.get("InsuranceBudget"));
		
		JSONObject joAttributes = new JSONObject();
		joAttributes.put("country", "CN");
		joAttributes.put("productType", "HappyLife");
		joAttributes.put("detailJson", joDetailJson.toString());
		joAttributes.put("transactionId", "c08f5dd3b95b460e9dc65872e450a510");
		
		JSONObject joData = new JSONObject();
		joData.put("type", "cnquotations");
		joData.put("attributes", joAttributes);
		
		JSONObject joRequest = new JSONObject();
		joRequest.put("data", joData);
		return joRequest.toString();
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		ValidationUtil.assertEquals(strStatusCode, "201", "Check response code");
		String strRestResponse = mapRequestResult.get("RestResponse").toString();
		
		JSONObject joResponse = new JSONObject(strRestResponse);
		JSONObject joData = joResponse.getJSONObject("data");
		JSONObject joAttributes = joData.getJSONObject("attributes");
		boolean bAffordableActual = joAttributes.getBoolean("affordable");
		ValidationUtil.assertEquals(bAffordableActual, Boolean.parseBoolean(data.get("Affordable")), "Check affordable");
		if (bAffordableActual == false) {
			JSONArray jaAffordabilityMessages = joAttributes.getJSONArray("affordabilityMessages");
			String[] strWarningCodes = data.get("WarningCodes").split("\\|");
			for (int i = 0; i < jaAffordabilityMessages.length(); i++) {
				ValidationUtil.assertEquals(String.valueOf(jaAffordabilityMessages.getJSONObject(i).getInt("id")), strWarningCodes[i], "Check AffordabilityMessage " + strWarningCodes[i]);
			}
		}
	}
	
}
