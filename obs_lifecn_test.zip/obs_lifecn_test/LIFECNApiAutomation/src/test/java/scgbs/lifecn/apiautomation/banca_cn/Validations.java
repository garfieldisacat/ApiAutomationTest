package scgbs.lifecn.apiautomation.banca_cn;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.RestUtil;
import scgbs.lifecn.apiautomation.SQLServerUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;

import org.json.JSONObject;
import org.json.JSONArray;


public class Validations extends APIBaseTest {
	
	@BeforeClass
	public void initializeDBTable() throws Exception {
		System.out.println("********* Start of initializing the DB Table obs_blc_wlc *********");
		SQLServerUtil objSqlServerConn = null;
		try {
			objSqlServerConn = new SQLServerUtil(ConfigurationUtil.getPropertyByName("SQLServer-Connection-URL"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-UserName"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-Password"));
			objSqlServerConn.initializeBeforeExecuteSQL();
			Date dtToday = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String strToday = sdf.format(dtToday);
			objSqlServerConn.executeStatement("update obs_job_audit set last_success_date = '" + strToday + "' where job_name = 'BLCWLC:Job:'");
			objSqlServerConn.executeStatement("delete from obs_blc_wlc");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300202148', 'WLC', null,  null, 'Y', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300124952', 'wLc', null,  null, 'Y', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300250030', 'wlc', null,  null, 'Y', '2018-08-08')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300256463', 'WCc',  null, null, 'Y', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300642110', 'WLC', 'BLC', null, 'Y', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300301892', null,  'BLC', null, 'Y', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300751561', null,  'blc', null, 'Y', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300007200', null,  'blc', null, 'Y', '2018-08-08')");
			objSqlServerConn.executeStatement("INSERT INTO obs_blc_wlc(REL_ID, WLC, BLC, EXT_INFO, is_active, updated_date) values ('300550076', null,  'bcc', null, 'Y', '" + strToday + "')");
		}
		catch (Exception e) {
			
		}
		finally {
			objSqlServerConn.closeAfterExecuteSQL();
			System.out.println("********* End of initializing the DB Table obs_blc_wlc *********");
		}
	}
	
	@AfterClass
	public void cleanDBTable() throws Exception {
		System.out.println("********* Start of cleaning the DB Table obs_blc_wlc *********");
		SQLServerUtil objSqlServerConn = null;
		try {
			objSqlServerConn = new SQLServerUtil(ConfigurationUtil.getPropertyByName("SQLServer-Connection-URL"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-UserName"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-Password"));
			objSqlServerConn.initializeBeforeExecuteSQL();
			objSqlServerConn.executeStatement("delete from obs_blc_wlc");
		}
		catch (Exception e) {
			
		}
		finally {
			objSqlServerConn.closeAfterExecuteSQL();
			System.out.println("********* End of cleaning the DB Table obs_blc_wlc *********");
		}
	}
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException {
		System.out.println("====== Run the test case " + data.get("CaseInfo") + " with the user " + data.get("RelationshipId") + " ======");
		String strAddress = ConfigurationUtil.getPropertyByName("OBS-CN-Backend") + "/banca/cn/validations";
		String strRestRequest = generateRestRequest(data);
		Map<String, String> mapHeaders = new HashMap<String, String>();
		mapHeaders.put("csl_user", "{\"relId\":\"" + data.get("RelationshipId") + "\"}");
		Map<String, Object> mapRequestResult = RestUtil.getRestResponseByPost(strAddress, strRestRequest, mapHeaders);
		checkPoints(data, mapRequestResult);
	}
	
	private String generateRestRequest(Map<String, String> data) {
		JSONArray jaValidationSteps = new JSONArray();
		String[] strValidationSteps = data.get("ValidationSteps").split("\\|");
		
		for (int i = 0; i < strValidationSteps.length; i++) {
			JSONObject joValidationStep = new JSONObject();
			int iStep = Integer.parseInt(strValidationSteps[i]);
			joValidationStep.put("step", iStep);
			if ((iStep == 16 || iStep == 9 || iStep == 21) && !("/".equals(data.get("ApplicantDetailsParameterValues")))) {
				String[] strParameterValues = data.get("ApplicantDetailsParameterValues").split("\\|");
				
				JSONObject joApplicantDetailsParameters = new JSONObject();
				joApplicantDetailsParameters.put("one", strParameterValues[0]);
				joApplicantDetailsParameters.put("two", strParameterValues[1]);
				joApplicantDetailsParameters.put("three", strParameterValues[2]);
				joApplicantDetailsParameters.put("four", strParameterValues[3]);
				joApplicantDetailsParameters.put("five", strParameterValues[4]);
				joApplicantDetailsParameters.put("six", strParameterValues[5]);
				joApplicantDetailsParameters.put("seven", strParameterValues[6]);
				joApplicantDetailsParameters.put("eight", strParameterValues[7]);
				joApplicantDetailsParameters.put("nine", strParameterValues[8]);
				joApplicantDetailsParameters.put("ten", strParameterValues[9]);
				joValidationStep.put("parameters", joApplicantDetailsParameters);
			}
			if ((iStep == 15) && !("/".equals(data.get("PaymentParameterValues")))) {
				JSONObject joPaymentParameters = new JSONObject();
				joPaymentParameters.put("amount", Double.parseDouble(data.get("PaymentParameterValues")));
				joValidationStep.put("parameters", joPaymentParameters);
			}
			jaValidationSteps.put(joValidationStep);
		}
		
		JSONObject joAttributes = new JSONObject();
		joAttributes.put("validationSteps", jaValidationSteps);
		
		JSONObject joData = new JSONObject();
		joData.put("attributes", joAttributes);
		joData.put("type", "validations");
		
		JSONObject joRequest = new JSONObject();
		joRequest.put("data", joData);
		return joRequest.toString();
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		ValidationUtil.assertEquals(strStatusCode, "201", "Check response code");
		String strRestResponse = mapRequestResult.get("RestResponse").toString();
		
		JSONObject joResponse = new JSONObject(strRestResponse);
		JSONObject joData = joResponse.getJSONObject("data");
		JSONObject joAttributes = joData.getJSONObject("attributes");
		boolean bValidateResultActual = joAttributes.getBoolean("validateResult");
		ValidationUtil.assertEquals(bValidateResultActual, Boolean.parseBoolean(data.get("ValidateResult")), "Check validate result");
		if (!("/".equals(data.get("ErrorCode")))) {
			boolean bFoundExpectedErrorCode = false;
			JSONArray jaErrorDetails = joAttributes.getJSONArray("errorDetails");
			for (int i = 0; i < jaErrorDetails.length(); i++) {
				if (data.get("ErrorCode").equals(String.valueOf(jaErrorDetails.getJSONObject(i).getInt("errorCode")))) {
					bFoundExpectedErrorCode = true;
					break;
				}
			}
			ValidationUtil.assertTrue(bFoundExpectedErrorCode, "Check error code " + data.get("ErrorCode"));
		}
	}
	
}
