package scgbs.lifecn.apiautomation;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.testng.annotations.Test;


public class DebugTestXPath {
	
	@Test
	public void test1() throws IOException, DocumentException {
		String strSoapResponse = getSoapResponse();
		
		Map<String, String> mapNameSpaces = new HashMap<String, String>();
		mapNameSpaces.put("defaultns", "http://www.finantix.com");
		mapNameSpaces.put("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
		
		Node node1 = XMLUtil.findNodeByXPath(strSoapResponse, "//SOAP-ENV:Body", mapNameSpaces);
		System.out.println("node1: " + node1.getText());
		Node node2 = XMLUtil.findNodeByXPath(strSoapResponse, "//defaultns:RCIPWebService-getCIPQuestions.Response", mapNameSpaces);
		System.out.println("node2: " + node2.getText());
		Node node3 = XMLUtil.findNodeByXPath(strSoapResponse, "//defaultns:Rtti", mapNameSpaces);
		System.out.println("node3: " + node3.getText());
		//Assert.assertEquals(node.getText(), "Account Number and Currency Code combination provided is not correct. Please provide a valid account number and currency code combination.", "Check //ns:description");
	    
	    /*
	    List<Node> list = XMLUtil.findNodesByXPath(strSoapResponse, "//ns:subTypeName", mapNameSpaces);
		Iterator<Node> iter = list.iterator();
		while (iter.hasNext()) {
			Element item = (Element) iter.next();
			Assert.assertEquals(item.getText(), "getAccountDetails1", "Check //ns:subTypeName");
		}
		*/
	}
	
	private String getSoapResponse() {
		StringBuffer sbResponse = new StringBuffer();
		//sbResponse.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
		sbResponse.append("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tns=\"http://www.finantix.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
		sbResponse.append("  <SOAP-ENV:Header />");
		sbResponse.append("  <SOAP-ENV:Body>");
		sbResponse.append("    <RCIPWebService-getCIPQuestions.Response xmlns=\"http://www.finantix.com\">");
		//sbResponse.append("    <RCIPWebService-getCIPQuestions.Response>");
		sbResponse.append("      <result>");
		sbResponse.append("        <isError>false</isError>");
		sbResponse.append("        <blockList>");
		sbResponse.append("          <Rtti>List[block]</Rtti>");
		sbResponse.append("        </blockList>");
		sbResponse.append("      </result>");
		sbResponse.append("    </RCIPWebService-getCIPQuestions.Response>");
		sbResponse.append("  </SOAP-ENV:Body>");
		sbResponse.append("</SOAP-ENV:Envelope>");
		return sbResponse.toString();
	}
	
}
