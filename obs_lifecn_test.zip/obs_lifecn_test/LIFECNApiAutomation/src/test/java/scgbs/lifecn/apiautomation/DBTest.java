package scgbs.lifecn.apiautomation;

import org.testng.annotations.Test;


public class DBTest {
	
	@Test
	public void test1() throws Exception {
		SQLServerUtil objSqlServerConn = null;
		try {
			objSqlServerConn = new SQLServerUtil(ConfigurationUtil.getPropertyByName("SQLServer-Connection-URL"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-UserName"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-Password"));
			objSqlServerConn.initializeBeforeExecuteSQL();
			objSqlServerConn.executeStatement("");
		}
		catch (Exception e) {
			
		}
		finally {
			objSqlServerConn.closeAfterExecuteSQL();
		}
	}
	
}
