package scgbs.lifecn.apiautomation.banca_cn;

import java.io.IOException;
import java.util.Map;

import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.RestUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;

import org.json.JSONArray;
import org.json.JSONObject;


public class WebComponent extends APIBaseTest {
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException {
		System.out.println("====== Run the test case " + data.get("CaseInfo") + " with the user " + data.get("RelationshipId") + " ======");
		String strAddress = ConfigurationUtil.getPropertyByName("OBS-CN-Backend") + "/banca/cn/webcomponents/" + data.get("RootElementId");
		Map<String, Object> mapRequestResult = RestUtil.getRestResponseByGet(strAddress, null);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		ValidationUtil.assertEquals(strStatusCode, "200", "Check response code");
		String strRestResponse = mapRequestResult.get("RestResponse").toString();
		
		JSONObject joResponse = new JSONObject(strRestResponse);
		JSONObject joData = joResponse.getJSONObject("data");
		JSONObject joAttributes = joData.getJSONObject("attributes");
		JSONArray jaComponentDtos = joAttributes.getJSONArray("componentDtos");
		
		
		if (!"/".equals(data.get("PaymentTerm"))) {
			for (int i = 0; i < jaComponentDtos.length(); i++) {
				JSONObject joComponentDto = jaComponentDtos.getJSONObject(i);
				JSONObject joProperties = joComponentDto.getJSONObject("properties");
				if ("paymentFrequency".equals(joProperties.getString("fieldName"))) {
					JSONArray jaValues = joProperties.getJSONArray("values");
					
					String[] strPaymentFrequencies = data.get("PaymentFrequency").split("\\|");
					for (int j = 0; j < strPaymentFrequencies.length; j++) {
						JSONObject joValue = jaValues.getJSONObject(j);
						ValidationUtil.assertEquals(joValue.getString("value"), strPaymentFrequencies[j], "Check payment frequency option " + (j+1));
					}
				}
				if ("paymentTerm".equals(joProperties.getString("fieldName"))) {
					JSONArray jaValues = joProperties.getJSONArray("values");
					
					String[] strPaymentFrequencies = data.get("PaymentTerm").split("\\|");
					for (int j = 0; j < strPaymentFrequencies.length; j++) {
						JSONObject joValue = jaValues.getJSONObject(j);
						ValidationUtil.assertEquals(joValue.getString("value"), strPaymentFrequencies[j], "Check payment term option " + (j+1));
					}
				}
			}
		}
		else {
			for (int i = 0; i < jaComponentDtos.length(); i++) {
				JSONObject joComponentDto = jaComponentDtos.getJSONObject(i);
				JSONObject joProperties = joComponentDto.getJSONObject("properties");
				if ("paymentTerm".equals(joProperties.getString("fieldName"))) {
					ValidationUtil.assertTrue(false, "Check payment term not appearing");
				}
				if ("paymentFrequency".equals(joProperties.getString("fieldName"))) {
					JSONArray jaValues = joProperties.getJSONArray("values");
					
					String[] strPaymentFrequencies = data.get("PaymentFrequency").split("\\|");
					for (int j = 0; j < strPaymentFrequencies.length; j++) {
						JSONObject joValue = jaValues.getJSONObject(j);
						ValidationUtil.assertEquals(joValue.getString("value"), strPaymentFrequencies[j], "Check payment frequency option " + (j+1));
					}
				}
			}
		}
	}
	
}
