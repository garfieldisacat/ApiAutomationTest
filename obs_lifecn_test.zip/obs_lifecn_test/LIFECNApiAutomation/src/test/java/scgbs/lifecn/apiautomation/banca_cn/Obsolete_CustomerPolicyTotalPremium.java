package scgbs.lifecn.apiautomation.banca_cn;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.RestUtil;
import scgbs.lifecn.apiautomation.SQLServerUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;

import org.json.JSONObject;


public class Obsolete_CustomerPolicyTotalPremium extends APIBaseTest {
	
	@BeforeClass
	public void initializeDBTable() throws Exception {
		System.out.println("********* Start of initializing the DB Table obs_customer_policy *********");
		SQLServerUtil objSqlServerConn = null;
		try {
			objSqlServerConn = new SQLServerUtil(ConfigurationUtil.getPropertyByName("SQLServer-Connection-URL"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-UserName"), ConfigurationUtil.getPropertyByName("SQLServer-Connection-Password"));
			objSqlServerConn.initializeBeforeExecuteSQL();
			Date dtToday = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String strToday = sdf.format(dtToday);
			objSqlServerConn.executeStatement("delete from obs_customer_policy");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027181', '300250030', 100.00,     'Y', 'Y', '10', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027182', '300223213', 3.35,       'Y', 'Y', '10', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027183', '300013766', 6.60,       'N', 'Y', '10', '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027184', '300638238', 7.00,       'Y', 'Y', '0',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027185', '300240998', 8.00,       'Y', 'N', '5',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027186', '300202148', 9.00,       'Y', 'Y', '5',  '2018-08-08')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027187', '300201763', 200.12,     'Y', 'Y', '5',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027188', '300201763', 5000000.13, 'Y', 'Y', '5',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027189', '300201763', 300.00,     'N', 'Y', '5',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027190', '300201763', 400.00,     'Y', 'Y', '0',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027191', '300201763', 500.00,     'Y', 'N', '5',  '" + strToday + "')");
			objSqlServerConn.executeStatement("INSERT INTO obs_customer_policy(UNITBAR_CODE, REL_ID, IP_BASE_PREMIUM, POLICY_STATUS, IS_ACTIVE, IP_PREMIUM_TERM, UPDATED_DATE) values ('TJ06A034027192', '300201763', 500.00,     'Y', 'N', '5',  '2018-08-08')");
		}
		catch (Exception e) {
			
		}
		finally {
			objSqlServerConn.closeAfterExecuteSQL();
			System.out.println("********* End of initializing the DB Table obs_customer_policy *********");
		}
	}
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException {
		System.out.println("====== Run the test case " + data.get("CaseInfo") + " with the user " + data.get("RelationshipId") + " ======");
		String strAddress = ConfigurationUtil.getPropertyByName("OBS-CN-Backend") + "/banca/cn/api/customerPolicyTotalPremium/" + data.get("RelationshipId");
		Map<String, Object> mapRequestResult = RestUtil.getRestResponseByGet(strAddress, null);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		ValidationUtil.assertEquals(strStatusCode, "200", "Check response code");
		String strRestResponse = mapRequestResult.get("RestResponse").toString();
		
		JSONObject joResponse = new JSONObject(strRestResponse);
		JSONObject joData = joResponse.getJSONObject("data");
		JSONObject joAttributes = joData.getJSONObject("attributes");
		double dTotalPremiumActual = joAttributes.getDouble("totalPremium");
		ValidationUtil.assertEquals(dTotalPremiumActual, Double.parseDouble(data.get("TotalPremium")), "Check TotalPremium");
	}
	
}
