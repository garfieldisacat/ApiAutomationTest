package scgbs.lifecn.apiautomation.banca_cn;

import java.io.IOException;
import java.util.Map;

import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.RestUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;

import org.json.JSONObject;


public class Product extends APIBaseTest {
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException {
		System.out.println("====== Run the test case " + data.get("CaseInfo") + " ======");
		String strAddress = ConfigurationUtil.getPropertyByName("OBS-CN-Backend") + "/banca/cn/products/" + data.get("ProductId");
		Map<String, Object> mapRequestResult = RestUtil.getRestResponseByGet(strAddress, null);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		ValidationUtil.assertEquals(strStatusCode, "200", "Check response code");
		String strRestResponse = mapRequestResult.get("RestResponse").toString();
		
		JSONObject joResponse = new JSONObject(strRestResponse);
		JSONObject joData = joResponse.getJSONObject("data");
		JSONObject joAttributes = joData.getJSONObject("attributes");
		String strAccountNameActual = joAttributes.getString("accountName");
		ValidationUtil.assertEquals(strAccountNameActual, data.get("AccountName"), "Check account name");
	}
	
}
