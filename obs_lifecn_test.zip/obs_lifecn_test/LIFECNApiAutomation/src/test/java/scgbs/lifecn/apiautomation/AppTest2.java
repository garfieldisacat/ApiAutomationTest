package scgbs.lifecn.apiautomation;

import org.testng.annotations.*;

public class AppTest2 {
	
	@BeforeSuite
	public void setUpSuite() {
		System.out.println("setUp Suite2");
	}
	
	@BeforeTest
	public void setUpTest() {
		System.out.println("setUp Test2");
	}
	
	@BeforeClass
	public void setUpClass() {
		System.out.println("setUp Class2");
	}
	
	@Test(groups = { "fast" })
	public void aFastTest() {
		System.out.println("Fast test2");
	}
	
	@Test(groups = { "slow" })
	public void aSlowTest() {
		System.out.println("Slow test2");
	}
	
}
