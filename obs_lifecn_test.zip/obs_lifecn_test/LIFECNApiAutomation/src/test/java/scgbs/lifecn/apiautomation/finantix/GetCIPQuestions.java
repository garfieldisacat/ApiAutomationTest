package scgbs.lifecn.apiautomation.finantix;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.Base64Util;
import scgbs.lifecn.apiautomation.CSVDataUtil;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.FileUtil;
import scgbs.lifecn.apiautomation.SoapUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;
import scgbs.lifecn.apiautomation.XMLUtil;


public class GetCIPQuestions {
	
	@DataProvider(name = "testdata")
	public Iterator<Object[]> Numbers() throws IOException {
		return (Iterator<Object[]>)new CSVDataUtil(this.getClass().getSimpleName(), FileUtil.getSubPackageName(this));
	}
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException, DocumentException {
		System.out.println("Run the test for user " + data.get("RelationshipId"));
		String strUserName = ConfigurationUtil.getPropertyByName("FinantixUserName");
		String strPassword = ConfigurationUtil.getPropertyByName("FinantixPassword");
		String strAddress = "http://10.20.172.253:9098/SCBWS1.2/services/RCIPWebService";
		String strSoapRequest = generateSoapRequest(data);
		Map<String, Object> mapRequestResult = SoapUtil.getSoapResponse(strUserName, strPassword, strAddress, strSoapRequest);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException, DocumentException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		Assert.assertEquals(strStatusCode, "200", "Check response code");
		String strSoapResponse = mapRequestResult.get("SoapResponse").toString();
		Map<String, String> mapNameSpaces = new HashMap<String, String>();
		mapNameSpaces.put("defaultns", "http://www.finantix.com");
		for(int i = 1; i <= 3; i++) {
			Node nodeAnswer = XMLUtil.findNodeByXPath(strSoapResponse, "//defaultns:Item[defaultns:subQuestionText = '" + Base64Util.encodeString(String.valueOf(data.get("Question" + i))) + "']/defaultns:listAnswer/defaultns:Item[defaultns:selected = 'true']/defaultns:text", mapNameSpaces);
			ValidationUtil.assertEquals(Base64Util.decodeString(nodeAnswer.getText()), data.get("Answer" + i), "Check the answer to the question " + i);
		}
	}
	
	private String generateSoapRequest(Map<String, String> data) {
		String strInputParamRelationshipId = String.valueOf(data.get("RelationshipId"));
		StringBuffer sbRequest = new StringBuffer();
		sbRequest.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:fin=\"http://www.finantix.com\">");
		sbRequest.append("  <soapenv:Header>");
		sbRequest.append("    <fin:FullContext>");
		sbRequest.append("      <fin:localeName></fin:localeName>");
		sbRequest.append("      <fin:country ExternalType=\"CHN\"/>");
		sbRequest.append("      <fin:currency ExternalType=\"RMB\"/>");
		sbRequest.append("      <fin:translationCode></fin:translationCode>");
		sbRequest.append("      <fin:languageCode>en_CN</fin:languageCode>");
		sbRequest.append("      <fin:workstationName></fin:workstationName>");
		sbRequest.append("      <fin:entityName></fin:entityName>");
		sbRequest.append("      <fin:channelName></fin:channelName>");
		sbRequest.append("    </fin:FullContext>");
		sbRequest.append("  </soapenv:Header>");
		sbRequest.append("  <soapenv:Body>");
		sbRequest.append("    <fin:RCIPWebService-getCIPQuestions.Request>");
		sbRequest.append("      <fin:questionnaireID>2720</fin:questionnaireID>");
		sbRequest.append("      <fin:customerId>" + strInputParamRelationshipId + "</fin:customerId>");
		sbRequest.append("      <fin:country>CHN</fin:country>");
		sbRequest.append("      <fin:segment>UHJlbWl1bQ==</fin:segment>");
		sbRequest.append("      <fin:getVerified>dHJ1ZQ==</fin:getVerified>");
		sbRequest.append("    </fin:RCIPWebService-getCIPQuestions.Request>");
		sbRequest.append("  </soapenv:Body>");
		sbRequest.append("</soapenv:Envelope>");
		return sbRequest.toString();
	}
	
}
