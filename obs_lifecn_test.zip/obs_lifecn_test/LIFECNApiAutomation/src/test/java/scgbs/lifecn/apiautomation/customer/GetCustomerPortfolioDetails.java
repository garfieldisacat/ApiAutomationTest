package scgbs.lifecn.apiautomation.customer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.testng.Assert;
import org.testng.annotations.Test;

import scgbs.lifecn.apiautomation.APIBaseTest;
import scgbs.lifecn.apiautomation.ConfigurationUtil;
import scgbs.lifecn.apiautomation.SoapUtil;
import scgbs.lifecn.apiautomation.ValidationUtil;
import scgbs.lifecn.apiautomation.XMLUtil;


public class GetCustomerPortfolioDetails extends APIBaseTest{
	
	@Test(dataProvider = "testdata")
	public void test(Map<String, String> data) throws IOException, DocumentException {
		System.out.println("Run the test for user " + data.get("CustomerIdentificationNumber"));
		String strUserName = ConfigurationUtil.getPropertyByName("OBSUserName");
		String strPassword = ConfigurationUtil.getPropertyByName("OBSPassword");
		String strAddress = "https://10.20.175.66:5501/ws/scbCoreBankingCustomer.v5.ws.provider.v3:Customer/scbCoreBankingCustomer_v5_ws_provider_v3_Customer_Port";
		String strSoapRequest = generateSoapRequest(data);
		Map<String, Object> mapRequestResult = SoapUtil.getSoapResponse(strUserName, strPassword, strAddress, strSoapRequest);
		checkPoints(data, mapRequestResult);
	}
	
	private void checkPoints(Map<String, String> data, Map<String, Object> mapRequestResult) throws IOException, DocumentException {
		String strStatusCode = mapRequestResult.get("StatusCode").toString();
		Assert.assertEquals(strStatusCode, "200", "Check response code");
		String strSoapResponse = mapRequestResult.get("SoapResponse").toString();
		Map<String, String> mapNameSpaces = new HashMap<String, String>();
		mapNameSpaces.put("ns", "http://www.sc.com/SCBML-1");
		mapNameSpaces.put("cust", "http://www.sc.com/coreBanking/v5/customer");
		Node nodeCurrencyCode = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:accountDetails[cust:currencyCode = '" + data.get("CurrencyCode") + "']", mapNameSpaces);
		Node nodeOperatingInstructions = XMLUtil.findNodeByXPath(strSoapResponse, "//cust:accountDetails[cust:currencyCode = '" + data.get("CurrencyCode") + "']/cust:operatingInstructions", mapNameSpaces);
		ValidationUtil.assertTrue(nodeCurrencyCode != null, "Check currencyCode");
		ValidationUtil.assertEquals(nodeOperatingInstructions.getText(), data.get("OperatingInstructions"), "Check operatingInstructions");
	}
	
	private String generateSoapRequest(Map<String, String> data) {
		String strCustomerIdentificationNumber = String.valueOf(data.get("CustomerIdentificationNumber"));
		StringBuffer sbRequest = new StringBuffer();
		sbRequest.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cus=\"http://www.sc.com/coreBanking/v5/ws/provider/customer\" xmlns:cus1=\"http://www.sc.com/coreBanking/v5/customer\" xmlns:java=\"java\" xmlns:scb=\"http://www.sc.com/SCBML-1\" xmlns:serUtil=\"eops.service.util.ServiceUtil\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
		sbRequest.append("  <soapenv:Header/>");
		sbRequest.append("  <soapenv:Body>");
		sbRequest.append("    <cus:getCustomerPortfolioDetails>");
		sbRequest.append("      <getCustomerPortfolioDetailsRequest>");
		sbRequest.append("        <scb:header>");
		sbRequest.append("          <scb:messageDetails>");
		sbRequest.append("            <scb:messageVersion>5.0</scb:messageVersion>");
		sbRequest.append("            <scb:messageType>");
		sbRequest.append("              <scb:typeName>CoreBanking:Customer</scb:typeName>");
		sbRequest.append("              <scb:subType>");
		sbRequest.append("                <scb:subTypeName>getCustomerPortfolioDetails</scb:subTypeName>");
		sbRequest.append("              </scb:subType>");
		sbRequest.append("            </scb:messageType>");
		sbRequest.append("          </scb:messageDetails>");
		sbRequest.append("          <scb:originationDetails>");
		sbRequest.append("            <scb:messageSender>");
		sbRequest.append("              <scb:messageSender>OBS</scb:messageSender>");
		sbRequest.append("              <scb:senderDomain>");
		sbRequest.append("                <scb:domainName>CoreBanking</scb:domainName>");
		sbRequest.append("                <scb:subDomainName>");
		sbRequest.append("                  <scb:subDomainType>OBS</scb:subDomainType>");
		sbRequest.append("                </scb:subDomainName>");
		sbRequest.append("              </scb:senderDomain>");
		sbRequest.append("              <scb:countryCode>CN</scb:countryCode>");
		sbRequest.append("            </scb:messageSender>");
		sbRequest.append("            <scb:messageTimestamp>2017-03-13T06:35:32.961</scb:messageTimestamp>");
		sbRequest.append("            <scb:initiatedTimestamp>2017-03-13T06:35:32.961</scb:initiatedTimestamp>");
		sbRequest.append("            <scb:trackingId>5abf32a6-3360-423a-9a16-4e1bc7b38cdb</scb:trackingId>");
		sbRequest.append("            <scb:possibleDuplicate>true</scb:possibleDuplicate>");
		sbRequest.append("          </scb:originationDetails>");
		sbRequest.append("          <scb:captureSystem>eBBS</scb:captureSystem>");
		sbRequest.append("          <scb:process>");
		sbRequest.append("            <scb:processName>getCustomerPortfolioDetails</scb:processName>");
		sbRequest.append("            <scb:eventType>get</scb:eventType>");
		sbRequest.append("          </scb:process>");
		sbRequest.append("        </scb:header>");
		sbRequest.append("        <cus1:getCustomerPortfolioDetailsReqPayload>");
		sbRequest.append("          <scb:payloadFormat>XML</scb:payloadFormat>");
		sbRequest.append("          <scb:payloadVersion>5.4</scb:payloadVersion>");
		sbRequest.append("          <cus1:getCustomerPortfolioDetailsReq>");
		sbRequest.append("            <cus1:customerIdentificationNumber>" + strCustomerIdentificationNumber + "</cus1:customerIdentificationNumber>");
		sbRequest.append("          </cus1:getCustomerPortfolioDetailsReq>");
		sbRequest.append("        </cus1:getCustomerPortfolioDetailsReqPayload>");
		sbRequest.append("      </getCustomerPortfolioDetailsRequest>");
		sbRequest.append("    </cus:getCustomerPortfolioDetails>");
		sbRequest.append("  </soapenv:Body>");
		sbRequest.append("</soapenv:Envelope>");
		return sbRequest.toString();
	}
	
}
