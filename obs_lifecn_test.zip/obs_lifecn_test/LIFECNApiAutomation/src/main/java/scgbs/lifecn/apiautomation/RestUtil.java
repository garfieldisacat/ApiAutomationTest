package scgbs.lifecn.apiautomation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.protocol.Protocol;


public class RestUtil {
	
	private static final String strDefaultCharSet = "UTF-8";
	private static final String strDefaultContentType = "application/vnd.api+json;charset=utf-8";
	
	public static Map<String, Object> getRestResponseByPost(String strServiceAddress, String strRestRequest, Map<String, String> mapHeaders) {
		return getRestResponseByPost(strServiceAddress, strRestRequest, mapHeaders, strDefaultCharSet, strDefaultContentType);
	}
	
    /**
     * @param charSet			Sample Value: UTF-8
     * @param contentType		Sample Value: application/vnd.api+json;charset=utf-8
     */
	public static Map<String, Object> getRestResponseByPost(String strServiceAddress, String strRestRequest, Map<String, String> mapHeaders, String strCharSet, String strContentType) {
		System.out.println("### Post Request: " + strServiceAddress);
		System.out.println("### Request Body: " + strRestRequest);
		Map<String, Object> mapRequestResult = new HashMap<String, Object>();
		PostMethod postMethod = new PostMethod(strServiceAddress);
		HttpClient httpClient = new HttpClient();
		Protocol myhttps = new Protocol("https", new HTTPSSecureProtocolSocketFactory(), 443); //To support HTTPS without any certificate
		Protocol.registerProtocol("https", myhttps);
		String strStatusCode = "";
		try {
			StringRequestEntity entity = new StringRequestEntity(strRestRequest, strContentType, strCharSet);
			postMethod.setRequestEntity(entity);
			if (mapHeaders != null) {
				for (Map.Entry<String, String> entry : mapHeaders.entrySet()) {
					postMethod.setRequestHeader(entry.getKey(), entry.getValue());
				}
			}
			
			strStatusCode = String.valueOf(httpClient.executeMethod(postMethod));
			System.out.println("### Response Status Code: " + strStatusCode);
			mapRequestResult.put("StatusCode", strStatusCode);
		}
		catch (IOException e) {
			throw new RuntimeException("Failed to send request: ", e);
		}
		if (!strStatusCode.startsWith("4") && !strStatusCode.startsWith("5")) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(postMethod.getResponseBodyAsStream()));
				StringBuffer sbRestResponse = new StringBuffer();
				String strTemp = "";
				while((strTemp = br.readLine()) != null){
					sbRestResponse.append(strTemp);
				}
				String strRestResponse = sbRestResponse.toString();
				System.out.println("### Response Body: " + strRestResponse);
				mapRequestResult.put("RestResponse", strRestResponse);
			}
			catch (IOException e) {
				throw new RuntimeException("Failed to get response data: ", e);
			}
		}
		else {
			throw new RuntimeException("Request failed with status code: " + strStatusCode);
		}
		return mapRequestResult;
	}
	
	public static Map<String, Object> getRestResponseByGet(String strServiceAddress, Map<String, String> mapHeaders) {
		System.out.println("### Get Request: " + strServiceAddress);
		Map<String, Object> mapRequestResult = new HashMap<String, Object>();
		GetMethod getMethod = new GetMethod(strServiceAddress);
		HttpClient httpClient = new HttpClient();
		Protocol myhttps = new Protocol("https", new HTTPSSecureProtocolSocketFactory(), 443); //To support HTTPS without any certificate
		Protocol.registerProtocol("https", myhttps);
		String strStatusCode = "";
		try {
			if (mapHeaders != null) {
				for (Map.Entry<String, String> entry : mapHeaders.entrySet()) {
					getMethod.setRequestHeader(entry.getKey(), entry.getValue());
				}
			}
			strStatusCode = String.valueOf(httpClient.executeMethod(getMethod));
			System.out.println("### Response Status Code: " + strStatusCode);
			mapRequestResult.put("StatusCode", strStatusCode);
		}
		catch (IOException e) {
			throw new RuntimeException("Failed to send request: ", e);
		}
		if (!strStatusCode.startsWith("4") && !strStatusCode.startsWith("5")) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(getMethod.getResponseBodyAsStream()));
				StringBuffer sbRestResponse = new StringBuffer();
				String strTemp = "";
				while((strTemp = br.readLine()) != null){
					sbRestResponse.append(strTemp);
				}
				String strRestResponse = sbRestResponse.toString();
				System.out.println("### Response Body: " + strRestResponse);
				mapRequestResult.put("RestResponse", strRestResponse);
			}
			catch (IOException e) {
				throw new RuntimeException("Failed to get response data: ", e);
			}
		}
		else {
			throw new RuntimeException("Request failed with status code: " + strStatusCode);
		}
		return mapRequestResult;
	}
	
}
