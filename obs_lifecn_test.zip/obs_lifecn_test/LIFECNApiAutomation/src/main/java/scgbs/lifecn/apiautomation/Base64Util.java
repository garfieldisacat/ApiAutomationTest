package scgbs.lifecn.apiautomation;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;


public class Base64Util {
	
	private static final String strCharSet = "UTF-8";
	
	public static String decodeString(String strSource) throws UnsupportedEncodingException {
		if (null == strSource) {
			return null;
		}
		return new String(Base64.decodeBase64(strSource.getBytes(strCharSet)), strCharSet);
	}
	
	public static String encodeString(String strSource) throws UnsupportedEncodingException {
		if (null == strSource) {
			return null;
		}
		return new String(Base64.encodeBase64(strSource.getBytes(strCharSet)), strCharSet);
	}
	
}
