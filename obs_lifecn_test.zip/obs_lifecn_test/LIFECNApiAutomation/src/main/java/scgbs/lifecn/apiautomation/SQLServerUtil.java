package scgbs.lifecn.apiautomation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class SQLServerUtil {
	
	private String strConnectionUrl;
	private String strUser;
	private String strPassword;
	private String strDriver;
	
	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	
	public SQLServerUtil(String strConnectionUrl, String strUser, String strPassword) throws Exception {
		this.strConnectionUrl = strConnectionUrl;
		this.strUser = strUser;
		this.strPassword = strPassword;
		this.strDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	}
	
	public void initializeBeforeExecuteSQL() throws Exception {
		try {
			Class.forName(strDriver);
			conn = DriverManager.getConnection(this.strConnectionUrl, this.strUser, this.strPassword);
			stmt = conn.createStatement();
		}
		catch (Exception exp) {
			System.out.println("Exception caught when initializing the connection before executing SQL");
			throw exp;
		}
	}
	
	public void setStatement(Statement stmt) {
		this.stmt = stmt;
	}
	
	public Statement getStatement() {		
		return stmt;
	}
	
	public void setConnection(Connection conn) {
		this.conn = conn;
	}
	
	public Connection getConnection() {		
		return conn;
	}
	
	public void closeAfterExecuteSQL() throws Exception {
		try {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		catch (Exception exp) {
			System.out.println("Exception caught when closing the connection after executing SQL");
			throw exp;
		}
	}
	
	public ResultSet executeQuery(String strSQLStatement) throws Exception {
		try {
			rs = stmt.executeQuery(strSQLStatement);
			return rs;
		}
		catch (Exception exp) {
			System.out.println("Exception caught when executing the SQL Query [" + strSQLStatement + "]");
			throw exp;
		}
	}
	
	public void executeStatement(String strSQLStatement) throws Exception {
		try {
			stmt.addBatch(strSQLStatement);
			stmt.executeBatch();
			conn.commit();
		}
		catch (Exception exp) {
			System.out.println("Exception caught when executing the SQL Statement [" + strSQLStatement + "]");
			throw exp;
		}
	}
	
}
