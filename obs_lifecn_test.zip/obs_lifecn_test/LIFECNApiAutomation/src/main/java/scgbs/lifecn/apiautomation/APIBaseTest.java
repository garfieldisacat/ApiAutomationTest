package scgbs.lifecn.apiautomation;

import java.io.IOException;
import java.util.Iterator;

import org.testng.annotations.DataProvider;

import scgbs.lifecn.apiautomation.CSVDataUtil;
import scgbs.lifecn.apiautomation.FileUtil;


public class APIBaseTest {
	
	@DataProvider(name = "testdata")
	public Iterator<Object[]> TestData() throws IOException {
		return (Iterator<Object[]>)new CSVDataUtil(this.getClass().getSimpleName(), FileUtil.getSubPackageName(this));
	}
	
}
