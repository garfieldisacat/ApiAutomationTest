package scgbs.lifecn.apiautomation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class CSVDataUtil implements Iterator<Object[]> {
	
	/**
	 * The content is split by comma (only those not inside the quotation marks)
	 * The quotation marks at the beginning and ending of each segment will be trimmed
	 */
	
	BufferedReader in;
	ArrayList<String> lstDataLinesOrigin = new ArrayList<String>();
	String strColumnNames[];
	int iRowNum = 0;
	int iColumnNum = 0;
	int iCurRowNo = 0;
	
	private static final String strCSVFileExtension = ".csv";
	private static final String strRegExOnlySplitByCommasOutOfQuotationMarks = ",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)";
	
	/**
	 * Initialize the test data file object and get all the columns
	 */
	public CSVDataUtil(String strFileName, String strSubPackageName) throws IOException {
		File csv = new File(FileUtil.getResourcesFolder() + strSubPackageName + "\\" + strFileName + strCSVFileExtension);
		in = new BufferedReader(new FileReader(csv));
		while (in.ready()) {
			lstDataLinesOrigin.add(in.readLine());
			this.iRowNum++;
		}
		String[] strFirstRowData = lstDataLinesOrigin.get(0).trim().split(strRegExOnlySplitByCommasOutOfQuotationMarks, -1);
		this.iColumnNum = strFirstRowData.length;
		strColumnNames = new String[iColumnNum];
		
		// Get all the Column Names
		for (int i = 0; i < iColumnNum; i++) {
			if (strFirstRowData[i] == null || "".equals(strFirstRowData[i])) {
				strColumnNames[i] = "";
			}
			else {
				String strTemp = strFirstRowData[i].trim();
				// Removing the starting or ending quotation mark if existing
				if (strTemp.indexOf("\"") == 0) {
					strTemp = strTemp.substring(1, strTemp.length());
				}
				if (strTemp.lastIndexOf("\"") == (strTemp.length() - 1)) {
					strTemp = strTemp.substring(0, strTemp.length() - 1);
				}
				strColumnNames[i] = strTemp;
			}
		}
		this.iCurRowNo++;
	}
	
	public boolean hasNext() {
		if (iRowNum == 0 || iCurRowNo >= iRowNum) {
			try {
				in.close();
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		}
		else {
			return true;
		}
	}
	
	/**
	 * Get the data for a record (a line)
	 */
	public Object[] next() {
		Map<String, String> mapDataLine = new HashMap<String, String>();
		String strCurRowData[] = lstDataLinesOrigin.get(iCurRowNo).trim().split(strRegExOnlySplitByCommasOutOfQuotationMarks, -1);
		for (int i = 0; i < iColumnNum; i++) {
			if (strCurRowData[i] == null || "".equals(strCurRowData[i])) {
				mapDataLine.put(strColumnNames[i], "");
			}
			else {
				String strTemp = strCurRowData[i].trim();
				// Removing the starting or ending quotation mark if existing
				if (strTemp.indexOf("\"") == 0) {
					strTemp = strTemp.substring(1, strTemp.length());
				}
				if (strTemp.lastIndexOf("\"") == (strTemp.length() - 1)) {
					strTemp = strTemp.substring(0, strTemp.length() - 1);
				}
				mapDataLine.put(strColumnNames[i], strTemp);
			}
		}
		Object[] objDataLine = new Object[1];
		objDataLine[0] = mapDataLine;
		this.iCurRowNo++;
		return objDataLine;
	}
	
}
