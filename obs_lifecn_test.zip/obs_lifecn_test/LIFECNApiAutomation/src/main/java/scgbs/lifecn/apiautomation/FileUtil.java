package scgbs.lifecn.apiautomation;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;


public class FileUtil {
	
	private static final String strResourceFilesPath = ".src.test.resources.";
	
	public static String getResourcesFolder() throws IOException {
		return new File(".").getCanonicalPath() + strResourceFilesPath.replaceAll("\\.", Matcher.quoteReplacement("\\"));
	}
	
	public static String getSubPackageName(Object objClass) throws IOException {
		String[] strPackageInfo = objClass.getClass().getPackage().getName().split("\\.");
		return strPackageInfo[strPackageInfo.length - 1];
	}
	
}
