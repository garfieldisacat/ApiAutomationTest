package scgbs.lifecn.apiautomation;

import org.jasypt.util.text.BasicTextEncryptor;


public class SensitiveDataEncryptUtils {
    
    public static String decrypt(String strInput, String strPassword) {
        BasicTextEncryptor btEncryptor = new BasicTextEncryptor();
        btEncryptor.setPassword(strPassword);
        return btEncryptor.decrypt(strInput);
    }
    
}
