package scgbs.lifecn.apiautomation;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;
import org.dom4j.xpath.DefaultXPath;


public class XMLUtil {
	
	public static Node findNodeByXPath(String strSoapResponse, String strXPathExpression, Map<String, String> mapNameSpaces) throws IOException, DocumentException {
		Document document = DocumentHelper.parseText(strSoapResponse);
		DefaultXPath xpath = new DefaultXPath(strXPathExpression);
		if (mapNameSpaces != null) {
			xpath.setNamespaceURIs(mapNameSpaces);
		}
		Node nodeResult = (Node)xpath.selectSingleNode(document);
		if (nodeResult != null) {
			System.out.println("Found the node using XPath [ " + strXPathExpression + " ]");
		}
		else {
			System.out.println("Failed to find the node using XPath [ " + strXPathExpression + " ]");
		}
		return nodeResult;
	}
	
	public static List<Node> findNodesByXPath(String strSoapResponse, String strXPathExpression, Map<String, String> mapNameSpaces) throws IOException, DocumentException {
		Document document = DocumentHelper.parseText(strSoapResponse);
		DefaultXPath xpath = new DefaultXPath(strXPathExpression);
		if (mapNameSpaces != null) {
			xpath.setNamespaceURIs(mapNameSpaces);
		}
		List<Node> nodeListResult = xpath.selectNodes(document);
		if (nodeListResult != null && nodeListResult.size() > 0) {
			System.out.println("Found the nodes using XPath [ " + strXPathExpression + " ]");
		}
		else {
			System.out.println("Failed to find the nodes using XPath [ " + strXPathExpression + " ]");
		}
		return nodeListResult;
	}
	
}
