package scgbs.lifecn.apiautomation;

import org.testng.Assert;


public class ValidationUtil {
	
	public static void assertEquals(String strActual, String strExpected, String strDescription) {
		String strResult = "PASSED --- ";
		if ((strActual == null) && (strExpected == null)) {
			
		}
		else if ((strActual == null) || (strExpected == null)) {
			strResult = "FAILED --- ";
		}
		else {
			if (!strActual.equals(strExpected)) {
				strResult = "FAILED --- ";
			}
		}
		System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName() + " " + strResult + strDescription + ", Actual Value [ " + strActual + " ], Expected Value [ " + strExpected + " ]");
		Assert.assertEquals(strActual, strExpected);
	}
	
	public static void assertEquals(boolean bActual, boolean bExpected, String strDescription) {
		String strResult = "PASSED --- ";
		if (bActual != bExpected) {
			strResult = "FAILED --- ";
		}
		System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName() + " " + strResult + strDescription + ", Actual Value [ " + bActual + " ], Expected Value [ " + bExpected + " ]");
		Assert.assertEquals(bActual, bExpected);
	}
	
	public static void assertEquals(double dActual, double dExpected, String strDescription) {
		String strResult = "PASSED --- ";
		if (dActual != dExpected) {
			strResult = "FAILED --- ";
		}
		System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName() + " " + strResult + strDescription + ", Actual Value [ " + dActual + " ], Expected Value [ " + dExpected + " ]");
		Assert.assertEquals(dActual, dExpected);
	}
	
	public static void assertTrue(boolean bCondition, String strDescription) {
		String strResult = "PASSED --- ";
		if (!bCondition) {
			strResult = "FAILED --- ";
		}
		System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName() + " " + strResult + strDescription);
		Assert.assertTrue(bCondition);
	}
	
}
