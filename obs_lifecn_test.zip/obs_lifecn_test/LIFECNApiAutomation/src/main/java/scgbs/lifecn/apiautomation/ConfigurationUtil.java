package scgbs.lifecn.apiautomation;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;


public class ConfigurationUtil {
	
	private static Properties props = null;
	private final static String strGlobalConfigurationFileName = "properties.config";
	
	public static Properties getProperties() {
		try {
			FileInputStream inStream = new FileInputStream(new File(FileUtil.getResourcesFolder() + strGlobalConfigurationFileName));
			Properties properties = new Properties();
			properties.load(inStream);
			return properties;
		}
		catch (Exception exp) {
			return null;
		}
	}
	
	public static String getPropertyByName(String strPropertyName) {
		String strPropertyVal = "";
		try {
			props = getProperties();
			if (props != null) {
				strPropertyVal = props.getProperty(strPropertyName);
			}
			return strPropertyVal;
		}
		catch (Exception exp) {
			return null;
		}
	}
	
}
