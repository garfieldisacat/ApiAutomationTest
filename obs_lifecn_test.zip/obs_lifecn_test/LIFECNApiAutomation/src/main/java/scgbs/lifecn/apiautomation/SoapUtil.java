package scgbs.lifecn.apiautomation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
//import org.apache.commons.httpclient.UsernamePasswordCredentials;
//import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.protocol.Protocol;


public class SoapUtil {
	
	private static final String strDefaultCharSet = "UTF-8";
	private static final String strDefaultContentType = "text/xml; charset=UTF-8";
	
	public static Map<String, Object> getSoapResponse(String strUserName, String strPassword, String strServiceAddress, String strSoapRequest) {
		return getSoapResponse(strUserName, strPassword, strServiceAddress, strSoapRequest, strDefaultCharSet, strDefaultContentType);
	}
	
    /**
     * @param charSet			Sample Value: UTF-8
     * @param contentType		Sample Value: text/xml; charset=UTF-8
     */
	public static Map<String, Object> getSoapResponse(String strUserName, String strPassword, String strServiceAddress, String strSoapRequest, String strCharSet, String strContentType) {
		Map<String, Object> mapRequestResult = new HashMap<String, Object>();
		PostMethod postMethod = new PostMethod(strServiceAddress);
		HttpClient httpClient = new HttpClient();
		Protocol myhttps = new Protocol("https", new HTTPSSecureProtocolSocketFactory(), 443); //To support HTTPS without any certificate
		Protocol.registerProtocol("https", myhttps);
		String strStatusCode = "";
		try {
			//httpClient.getState().setCredentials(AuthScope.ANY, new UsernamePasswordCredentials("USERNAME", "PASSWORD"));
			StringRequestEntity entity = new StringRequestEntity(strSoapRequest, strContentType, strCharSet);
			postMethod.setRequestEntity(entity);
			//postMethod.setRequestHeader("Authorization", "Basic b2JzdXNlcjphYmMxMjM0NQ==");
			postMethod.setRequestHeader("Authorization", "Basic " + Base64Util.encodeString(strUserName + ":" + strPassword));
			strStatusCode = String.valueOf(httpClient.executeMethod(postMethod));
			mapRequestResult.put("StatusCode", strStatusCode);
		}
		catch (IOException e) {
			throw new RuntimeException("Failed to send request: ", e);
		}
		if (!strStatusCode.startsWith("4") && !strStatusCode.startsWith("5")) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(postMethod.getResponseBodyAsStream()));
				StringBuffer sbSoapResponse = new StringBuffer();
				String strTemp = "";
				while((strTemp = br.readLine()) != null){
					sbSoapResponse.append(strTemp);
				}
				String strSoapResponse = sbSoapResponse.toString();
				//System.out.println("Get response data successfully: " + strSoapResponse);
				mapRequestResult.put("SoapResponse", strSoapResponse);
			}
			catch (IOException e) {
				throw new RuntimeException("Failed to get response data: ", e);
			}
		}
		else {
			throw new RuntimeException("Request failed with status code: " + strStatusCode);
		}
		return mapRequestResult;
	}
	
}
